import Exceptions.*;
import Professores.Adjunto;
import Professores.Assistente;
import Professores.Associado;
import Professores.Auxiliar;
import Professores.Professor;
import Professores.Titular;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.InputMismatchException;
import java.util.Scanner;
import javax.swing.*;

import Alunos.Especial;
import Alunos.Graduacao;
import Alunos.PosGraduacao;
import Disciplinas.Disciplina;
import Disciplinas.Estagio;
import Disciplinas.Turma;

public class Menus {
	
	private static Graduacao alunograd = new Graduacao();
	private static PosGraduacao alunopos = new PosGraduacao();
	private static Especial alunoesp = new Especial();
	private static Auxiliar profaux = new Auxiliar();
	private static Assistente profassist = new Assistente();
	private static Adjunto profadj = new Adjunto();
	private static Associado profassoc = new Associado();
	private static Titular proftit = new Titular();
	private static Disciplina disc = new Disciplina();
	private static Estagio estg = new Estagio();
	private static Turma turm = new Turma();
	private static Professor prof = new Professor();

	static Scanner input = new Scanner(System.in);


	private static void cadastrar(String s, File f) throws IOException{
		
		FileWriter fw = new FileWriter(f, true);
		fw.write(s);
		fw.close();
	}

    static String menuPrincipal(){
        StringBuilder m = new StringBuilder();

        m.append("\n- Sistema de cadastro de Universidades -\n");
        m.append("1) Cadastrar aluno;\n");
        m.append("2) Cadastrar professor;\n");
        m.append("3) Cadastrar disciplina;\n");
        m.append("4) Cadastrar turma;\n");
        m.append("5) Cadastrar estágio;\n");
        m.append("0) Sair.\n");

        return m.toString();      
    }

    static void menuCadastrarAluno()
			throws ParseException, OpcaoInvalidaException, InputMismatchException, IOException, InformacaoFaltanteException, OrientadorNaoAtribuidoException {
        StringBuilder m = new StringBuilder();
        StringBuilder n = new StringBuilder();
        int opcao1 = 0;
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        java.util.Date data;
        
        m.append("\n- Cadastro de aluno -\n");
        m.append("1) Aluno de graduacao;\n");
        m.append("2) Aluno de pos-graduacao;\n");
        m.append("0) Voltar.\n");

        System.out.print(m.toString());
        
        opcao1 = AcoesMenus.escolhaAluno();

        // Aluno de graduação
        if(opcao1 == 1) {
        	System.out.print("\nDigite o Nome (sem espaços): ");
        	alunograd.setNome(input.next());
        	System.out.print("\nDigite a Matricula: ");
        	alunograd.setMatricula(input.nextInt());
        	System.out.print("\nDigite o Semestre de Ingresso: ");
        	alunograd.setSemestreIngresso(input.nextInt());
        	System.out.print("\nDigite o Ano de Ingresso: ");
        	alunograd.setAnoIngresso(input.nextInt());
        	System.out.print("\nDigite a forma de Ingresso (sem espaços): ");
        	alunograd.setFormaIngresso(input.next());
        	System.out.print("\nDigite o Curso de gradução (sem espaços): ");
        	alunograd.setCurso(input.next());
        	System.out.print("\nDigite a provável data de formatura (dd/mm/yyyy): ");
			data = formato.parse(input.next());
			alunograd.setProvavelDefesa(data);

			// Lançar excessão caso haja algum campo vazio
			if (alunograd.hasEmptyField()) {
				throw new InformacaoFaltanteException();
			}

			// Cadastrar caso não haja
			else {
				String s = alunograd.toString();
				File f = new File("Alunos_de_graduacao.txt");
				cadastrar(s + "\n", f);
				JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso!\n");
			}

        }

        // Cadastrar aluno de pós graduação
        else if(opcao1 == 2) {
        	n.append("\n1) Normal;\n");
        	n.append("2) Especial;\n");
        	n.append("0) Voltar.\n");
        	
        	System.out.print(n.toString());
        	
        	int opcao2 = AcoesMenus.escolhaAlunoPosGrad();
	
        	if(opcao2 == 1) {
		        System.out.print("\nDigite o Nome (sem espaços): ");
		       	alunopos.setNome(input.next());
		       	System.out.print("\nDigite a Matricula: ");
		       	alunopos.setMatricula(input.nextInt());
		       	System.out.print("\nDigite o Semestre de Ingresso: ");
		       	alunopos.setSemestreIngresso(input.nextInt());
		       	System.out.print("\nDigite o Ano de Ingresso: ");
		       	alunopos.setAnoIngresso(input.nextInt());
		       	System.out.print("\nDigite o Semestre de Qualificacao: ");
	        	alunopos.setSemestreQualificacao(input.nextInt());
		        System.out.print("\nDigite a Data Provável de Defesa (dd/mm/yyyy): ");
				data = formato.parse(input.next());
		        alunopos.setProvavelDefesa(data);
		        System.out.print("\nDigite o Nome do Professor (sem espaços): ");
				prof.setNome(input.next());
				System.out.print("\nDigite a Formacao do Professor (sem espaços): ");
				prof.setFormacao(input.next());
				System.out.print("\nDigite a Matricula SIAPE: ");
				prof.setMatriculaSiape(input.nextInt());
				System.out.print("\nDigite a Matricula FUB: ");
				prof.setMatriculaFUB(input.nextInt());
				System.out.print("\nDigite o Salario: ");
				prof.setSalario(input.nextFloat());
				alunopos.setOrientador(prof);

				// Caso não haja orientador atribuído, lançar excessão e mostrar informações do aluno num JOptionPane
				if (prof == null){
					JOptionPane.showMessageDialog(null, alunopos.toString());
					throw new OrientadorNaoAtribuidoException();
				}

				// Lançar excessão caso haja algum campo vazio
				else if (alunopos.hasEmptyField()) {
					throw new InformacaoFaltanteException();
				}

				// Cadastrar caso não haja
				else {
					String s = alunopos.toString();
					File f = new File("Alunos_de_pos.txt");
					cadastrar(s + "\n", f);
					JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso!\n");
				}

	        }
        	else if (opcao2 == 2) {
		        System.out.print("\nDigite o Nome (sem espaços): ");
		       	alunoesp.setNome(input.next());
		       	System.out.print("\nDigite a Matricula: ");
		       	alunoesp.setMatricula(input.nextInt());
		       	System.out.print("\nDigite o Semestre de Ingresso: ");
		       	alunoesp.setSemestreIngresso(input.nextInt());
		       	System.out.print("\nDigite o Ano de Ingresso: ");
		       	alunoesp.setAnoIngresso(input.nextInt());

		       	System.out.print("\nDigite o Semestre de Qualificacao: ");
		       	alunoesp.setSemestreQualificacao(input.nextInt());
		       	System.out.print("\nDigite a Data Provável de Defesa (dd/mm/yyyy): ");
				data = formato.parse(input.next());
				alunoesp.setProvavelDefesa(data);

		        System.out.print("\nDigite o Nome do Professor (sem espaços): ");
				prof.setNome(input.next());
				System.out.print("\nDigite a Formacao do Professor (sem espaços): ");
				prof.setFormacao(input.next());
				System.out.print("\nDigite a Matricula SIAPE: ");
				prof.setMatriculaSiape(input.nextInt());
				System.out.print("\nDigite a Matricula FUB: ");
				prof.setMatriculaFUB(input.nextInt());
				System.out.print("\nDigite o Salario: ");
				prof.setSalario(input.nextFloat());
				alunoesp.setOrientador(prof);

		        System.out.print("\nDigite se a Taxa foi Paga: ");
		        alunoesp.setTaxaPaga(input.nextBoolean());
		        System.out.print("\nDigite o Semestre Cursado (sem espaços): ");
		        alunoesp.setSemestreCursado(input.next());

				// Caso não haja orientador atribuído, lançar excessão e mostrar informações do aluno num JOptionPane
				if (prof == null){
					JOptionPane.showMessageDialog(null, alunoesp.toString());
					throw new OrientadorNaoAtribuidoException();
				}

				// Lançar excessão caso haja algum campo vazio
				else if(alunoesp.hasEmptyField()) {
					throw new InformacaoFaltanteException();
				}

				// Cadastrar caso não haja
				else {
					String s = alunoesp.toString();
					File f = new File("Alunos_especiais.txt");
					cadastrar(s + "\n", f);
					JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso!\n");
				}
        	}
        }
    }
    
    static void menuCadastrarProfessor()
			throws ParseException, OpcaoInvalidaException, InputMismatchException, IOException, InformacaoFaltanteException {
    	StringBuilder m = new StringBuilder();
    	int opcao = 0;
    	SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        java.util.Date data = null;
    	
    	m.append(" - Cadastro de professor -\n");
    	m.append("1) Professor Auxiliar;\n");
    	m.append("2) Professor Assistente;\n");
    	m.append("3) Professor Adjunto;\n");
    	m.append("4) Professor Associado;\n");
    	m.append("5) Professor Titular;\n");
    	m.append("0) Voltar.\n");
    	
    	System.out.print(m.toString());
    	
    	opcao = AcoesMenus.escolhaProfessor();
    	
    	if(opcao == 1) {
    		System.out.print("\nDigite o Nome do Professor (sem espaços): ");
    		profaux.setNome(input.next());
    		System.out.print("\nDigite a Formacao do Professor (sem espaços): ");
    		profaux.setFormacao(input.next());
    		System.out.print("\nDigite a Matricula SIAPE: ");
    		profaux.setMatriculaSiape(input.nextInt());
    		System.out.print("\nDigite a Matricula FUB: ");
    		profaux.setMatriculaFUB(input.nextInt());
    		System.out.print("\nDigite o Salario: ");
    		profaux.setSalario(input.nextFloat());
    		System.out.print("\nDigite a Graduacao (sem espaços): ");
    		profaux.setGraduacao(input.next());
    		System.out.print("\nDigite o Ano de Graduacao: ");
    		profaux.setAnoGraduacao(input.nextInt());

			if(profaux.hasEmptyField()) {
				throw new InformacaoFaltanteException();
			} else {
				String s = profaux.toString();
				File f = new File("Professores_auxiliares.txt");
				cadastrar(s + "\n", f);
				JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso!\n");
			}

    	}
    	else if (opcao == 2) {
    		System.out.print("\nDigite o Nome do Professor (sem espaços): ");
    		profassist.setNome(input.next());
    		System.out.print("\nDigite a Formacao do Professor (sem espaços): ");
    		profassist.setFormacao(input.next());
    		System.out.print("\nDigite a Matricula SIAPE: ");
    		profassist.setMatriculaSiape(input.nextInt());
    		System.out.print("\nDigite a Matricula FUB: ");
    		profassist.setMatriculaFUB(input.nextInt());
    		System.out.print("\nDigite o Salario: ");
    		profassist.setSalario(input.nextFloat());
    		System.out.print("\nDigite a Graduacao (sem espaços): ");
    		profassist.setGraduacao(input.next());
    		System.out.print("\nDigite o Ano de Graduacao: ");
    		profassist.setAnoGraduacao(input.nextInt());
    		System.out.print("\nDigite o Titulo da Dissertacao (sem espaços): ");
    		profassist.setTituloDissertacao(input.next());
    		System.out.print("\nDigite o Nome do Mestrado (sem espaços): ");
    		profassist.setMestrado(input.next());
    		System.out.print("\nDigite o Ano do Mestrado: ");
    		profassist.setAnoMestrado(input.nextInt());

			if(profassist.hasEmptyField()) {
				throw new InformacaoFaltanteException();
			} else {
				String s = profassist.toString();
				File f = new File("Professores_assistentes.txt");
				cadastrar(s + "\n", f);
				JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso!\n");
			}

    	}
    	else if(opcao == 3) {
    		System.out.print("\nDigite o Nome do Professor (sem espaços): ");
    		profadj.setNome(input.next());
    		System.out.print("\nDigite a Formacao do Professor (sem espaços): ");
    		profadj.setFormacao(input.next());
    		System.out.print("\nDigite a Matricula SIAPE: ");
    		profadj.setMatriculaSiape(input.nextInt());
    		System.out.print("\nDigite a Matricula FUB: ");
    		profadj.setMatriculaFUB(input.nextInt());
    		System.out.print("\nDigite o Salario: ");
    		profadj.setSalario(input.nextFloat());
    		System.out.print("\nDigite a Graduacao (sem espaços): ");
    		profadj.setGraduacao(input.next());
    		System.out.print("\nDigite o Ano de Graduacao: ");
    		profadj.setAnoGraduacao(input.nextInt());
    		System.out.print("\nDigite o Titulo da Dissertacao (sem espaços): ");
    		profadj.setTituloDissertacao(input.next());
    		System.out.print("\nDigite o Nome do Mestrado (sem espaços): ");
    		profadj.setMestrado(input.next());
    		System.out.print("\nDigite o Ano do Mestrado: ");
    		profadj.setAnoMestrado(input.nextInt());
    		System.out.print("\nDigite o Titulo da Tese (sem espaços): ");
    		profadj.setTituloTese(input.next());
    		System.out.print("\nDigite o Nome do Doutorado (sem espaços): ");
    		profadj.setDoutorado(input.next());
    		System.out.print("\nDigite o Ano do Doutorado: ");
    		profadj.setAnoDoutorado(input.nextInt());

			if(profadj.hasEmptyField()) {
				throw new InformacaoFaltanteException();
			} else {
				String s = profadj.toString();
				File f = new File("Professores_adjuntos.txt");
				cadastrar(s + "\n", f);
				JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso!\n");
			}

    	} else if (opcao == 4) {
    		System.out.print("\nDigite o Nome do Professor (sem espaços): ");
    		profassoc.setNome(input.next());
    		System.out.print("\nDigite a Formacao do Professor (sem espaços): ");
    		profassoc.setFormacao(input.next());
    		System.out.print("\nDigite a Matricula SIAPE: ");
    		profassoc.setMatriculaSiape(input.nextInt());
    		System.out.print("\nDigite a Matricula FUB: ");
    		profassoc.setMatriculaFUB(input.nextInt());
    		System.out.print("\nDigite o Salario: ");
    		profassoc.setSalario(input.nextFloat());
    		System.out.print("\nDigite a Graduacao (sem espaços): ");
    		profassoc.setGraduacao(input.next());
    		System.out.print("\nDigite o Ano de Graduacao: ");
    		profassoc.setAnoGraduacao(input.nextInt());
    		System.out.print("\nDigite o Titulo da Dissertacao (sem espaços): ");
    		profassoc.setTituloDissertacao(input.next());
    		System.out.print("\nDigite o Nome do Mestrado (sem espaços): ");
    		profassoc.setMestrado(input.next());
    		System.out.print("\nDigite o Ano do Mestrado: ");
    		profassoc.setAnoMestrado(input.nextInt());
    		System.out.print("\nDigite o Titulo da Tese (sem espaços): ");
    		profassoc.setTituloTese(input.next());
    		System.out.print("\nDigite o Nome do Doutorado (sem espaços): ");
    		profassoc.setDoutorado(input.next());
    		System.out.print("\nDigite o Ano do Doutorado: ");
    		profassoc.setAnoDoutorado(input.nextInt());
    		System.out.print("\nDigite a Area de Pesquisa (sem espaços): ");
    		profassoc.setAreaDePesquisa(input.next());

			if(profassoc.hasEmptyField()) {
				throw new InformacaoFaltanteException();
			} else {
				String s = profassoc.toString();
				File f = new File("Professores_associados.txt");
				cadastrar(s + "\n", f);
				JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso!\n");
			}

    	}
    	else if (opcao == 5) {
    		System.out.print("\nDigite o Nome do Professor (sem espaços): ");
    		proftit.setNome(input.next());
    		System.out.print("\nDigite a Formacao do Professor (sem espaços): ");
    		proftit.setFormacao(input.next());
    		System.out.print("\nDigite a Matricula SIAPE: ");
    		proftit.setMatriculaSiape(input.nextInt());
    		System.out.print("\nDigite a Matricula FUB: ");
    		proftit.setMatriculaFUB(input.nextInt());
    		System.out.print("\nDigite o Salario: ");
    		proftit.setSalario(input.nextFloat());
    		System.out.print("\nDigite a Graduacao (sem espaços): ");
    		proftit.setGraduacao(input.next());
    		System.out.print("\nDigite o Ano de Graduacao: ");
    		proftit.setAnoGraduacao(input.nextInt());
    		System.out.print("\nDigite o Titulo da Dissertacao (sem espaços): ");
    		proftit.setTituloDissertacao(input.next());
    		System.out.print("\nDigite o Nome do Mestrado (sem espaços): ");
    		proftit.setMestrado(input.next());
    		System.out.print("\nDigite o Ano do Mestrado: ");
    		proftit.setAnoMestrado(input.nextInt());
    		System.out.print("\nDigite o Titulo da Tese: ");
    		proftit.setTituloTese(input.next());
    		System.out.print("\nDigite o Nome do Doutorado (sem espaços): ");
    		proftit.setDoutorado(input.next());
    		System.out.print("\nDigite o Ano do Doutorado (sem espaços): ");
    		proftit.setAnoDoutorado(input.nextInt());
    		System.out.print("\nDigite a Area de Pesquisa (sem espaços): ");
    		proftit.setAreaDePesquisa(input.next());
    		System.out.print("\nDigite a Data do Concurso (dd/mm/yyyy): ");
			data = formato.parse(input.next());
    		proftit.setConcurso(data);
    		System.out.print("\nDigite a Data de Admissao (dd/mm/yyyy): ");
			data = formato.parse(input.next());
    		proftit.setDataDeAdmissao(data);

			if(proftit.hasEmptyField()) {
				throw new InformacaoFaltanteException();
			} else {
				String s = proftit.toString();
				File f = new File("Professores_titulares.txt");
				cadastrar(s + "\n", f);
				JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso!\n");
			}
    	}
    }
    
    static void menuCadastrarDisciplina() throws OpcaoInvalidaException, IOException, InformacaoFaltanteException {
    	StringBuilder m = new StringBuilder();
    	int opcao = 0;
    	
    	m.append(" - Cadastro de Disciplina -\n");
    	m.append("1) Disciplina Normal;\n");
    	m.append("2) Estágio;\n");
    	m.append("0) Voltar.\n");
    	
    	System.out.print(m.toString());
    	
    	opcao = AcoesMenus.escolhaDiscplina();
    	
    	if(opcao == 1) {
    		System.out.print("\nDigite o Nome da Disciplina (sem espaços): ");
    		disc.setNome(input.next());
    		System.out.print("\nDigite a Carga Horaria: ");
    		disc.setCargaHoraria(input.nextInt());

			if(disc.hasEmptyField()) {
				throw new InformacaoFaltanteException();
			} else {
				String s = disc.toString();
				File f = new File("Disciplina.txt");
				cadastrar(s + "\n", f);
				JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso!\n");
			}

    	}
    	else if(opcao == 2) {
    		System.out.print("\nDigite o Nome da Disciplina (sem espaços): ");
    		estg.setNome(input.next());
    		System.out.print("\nDigite a Carga Horaria: ");
    		estg.setCargaHoraria(input.nextInt());
    		System.out.print("\nDigite o Local do Estágio (sem espaços): ");
    		estg.setLocalDeEstagio(input.next());
    		System.out.print("\nDigite o Nome do Professor (sem espaços): ");
    		prof.setNome(input.next());
    		System.out.print("\nDigite a Formacao do Professor (sem espaços): ");
    		prof.setFormacao(input.next());
    		System.out.print("\nDigite a Matricula SIAPE: ");
    		prof.setMatriculaSiape(input.nextInt());
    		System.out.print("\nDigite a Matricula FUB: ");
    		prof.setMatriculaFUB(input.nextInt());
    		System.out.print("\nDigite o Salario: ");
    		prof.setSalario(input.nextFloat());
    		turm.setProfessor(prof);
    		estg.setResponsavel(prof);

			if(estg.hasEmptyField()) {
				throw new InformacaoFaltanteException();
			} else {
				String s = estg.toString();
				File f = new File("Estagio.txt");
				cadastrar(s + "\n", f);
				JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso!\n");
			}
    	}
    	
    }
    
    static void menuCadastrarTurma() throws IOException, InformacaoFaltanteException, ProfessorNaoAtribuidoException, DisciplinaNaoAtribuidaException {
    	
    	System.out.print("\nDigite o Codigo da Turma: ");
    	turm.setCodigo(input.nextInt());
    	System.out.print("\nDigite o Horario da Turma (sem espaços): ");
    	turm.setHorario(input.next());
		System.out.print("\nDigite o Nome da Disciplina (sem espaços): ");
		disc.setNome(input.next());
		System.out.print("\nDigite a Carga Horaria: ");
		disc.setCargaHoraria(input.nextInt());
		turm.setDisciplina(disc);
		System.out.print("\nDigite o Nome do Professor (sem espaços): ");
		prof.setNome(input.next());
		System.out.print("\nDigite a Formacao do Professor (sem espaços): ");
		prof.setFormacao(input.next());
		System.out.print("\nDigite a Matricula SIAPE: ");
		prof.setMatriculaSiape(input.nextInt());
		System.out.print("\nDigite a Matricula FUB: ");
		prof.setMatriculaFUB(input.nextInt());
		System.out.print("\nDigite o Salario: ");
		prof.setSalario(input.nextFloat());
		turm.setProfessor(prof);

		if (disc == null){
			throw new DisciplinaNaoAtribuidaException();
		} else if(prof == null){
			throw new ProfessorNaoAtribuidoException();
		} else if (proftit.hasEmptyField()) {
			throw new InformacaoFaltanteException();
		} else {
			String s = turm.toString();
			File f = new File("Turmas.txt");
			cadastrar(s + "\n", f);
			JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso!\n");
		}
    }

    static void menuCadastrarEstagio() throws ProfessorNaoAtribuidoException, InformacaoFaltanteException, IOException {
		System.out.println("\nDigite o Nome do estágio: ");
		estg.setNome(input.next());
		System.out.println("\nDigite a carga horária: ");
		estg.setCargaHoraria(input.nextInt());
		System.out.println("\nDigite o local do estágio: ");
    	estg.setLocalDeEstagio(input.next());

		System.out.print("\nDigite o Nome do Professor (sem espaços): ");
		prof.setNome(input.next());
		System.out.print("\nDigite a Formacao do Professor (sem espaços): ");
		prof.setFormacao(input.next());
		System.out.print("\nDigite a Matricula SIAPE: ");
		prof.setMatriculaSiape(input.nextInt());
		System.out.print("\nDigite a Matricula FUB: ");
		prof.setMatriculaFUB(input.nextInt());
		System.out.print("\nDigite o Salario: ");
		prof.setSalario(input.nextFloat());
    	estg.setResponsavel(prof);

    	if (prof == null) {
    		throw new ProfessorNaoAtribuidoException();
		} else if (estg.hasEmptyField()) {
    		throw new InformacaoFaltanteException();
		} else {
			String s = estg.toString();
			File f = new File("Estagios.txt");
			cadastrar(s + "\n", f);
			JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso!\n");
		}
	}

}
