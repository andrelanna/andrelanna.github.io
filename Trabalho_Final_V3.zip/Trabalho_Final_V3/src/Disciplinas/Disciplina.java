package Disciplinas;

/**
 * Created by Gustavo on 30/06/2017.
 */
public class Disciplina {
    private String nome;
    private int cargaHoraria;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(int cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public boolean hasEmptyField(){
        if (this.getNome().isEmpty() || this.getCargaHoraria() == 0){
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString(){
        StringBuilder bld = new StringBuilder();
        bld.append("\nNome da disciplina: "); bld.append(getNome());  bld.append(System.lineSeparator());
        bld.append("Carga horária: "); bld.append(getCargaHoraria());  bld.append(System.lineSeparator());
       
        return bld.toString();
    }
}
