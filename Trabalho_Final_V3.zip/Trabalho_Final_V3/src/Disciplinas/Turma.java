package Disciplinas;

import Professores.Professor;

/**
 * Created by Gustavo on 30/06/2017.
 */
public class Turma {
    private int codigo;
    private String horario;
    private Disciplina disciplina;
    private Professor professor;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public Disciplina getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(Disciplina disciplina) {
        this.disciplina = disciplina;
    }

    public Professor getProfessor() {
        return professor;
    }

    public void setProfessor(Professor professor) {
        this.professor = professor;
    }

    public boolean hasEmptyField(){
        if (this.getHorario().isEmpty() ||
                this.getCodigo() == 0 ||
                this.getDisciplina() == null ||
                this.getProfessor() == null) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        StringBuilder bld = new StringBuilder();

        bld.append("Código da disciplina:"); bld.append(this.getCodigo()); bld.append(System.lineSeparator());
        bld.append("Horário da disciplina:"); bld.append(this.getHorario()); bld.append(System.lineSeparator());
        bld.append(disciplina.toString()); bld.append(System.lineSeparator());
        bld.append("\nProfessor:"); bld.append(professor.toString()); bld.append(System.lineSeparator());


     return bld.toString();
    }
}
