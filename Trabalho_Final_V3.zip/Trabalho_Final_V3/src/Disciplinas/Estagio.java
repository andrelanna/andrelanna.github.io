package Disciplinas;

import Professores.Professor;

/**
 * Created by Gustavo on 30/06/2017.
 */
public class Estagio extends Disciplina {
    private String localDeEstagio;
    private Professor responsavel;

    public String getLocalDeEstagio() {
        return localDeEstagio;
    }

    public void setLocalDeEstagio(String localDeEstagio) {
        this.localDeEstagio = localDeEstagio;
    }

    public Professor getResponsavel() {
        return responsavel;
    }

    public void setResponsavel(Professor responsavel) {
        this.responsavel = responsavel;
    }

    public boolean hasEmptyField(){
        if (super.hasEmptyField() ||
                this.getLocalDeEstagio().isEmpty() ||
                this.getResponsavel() == null) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        StringBuilder bld = new StringBuilder();
        bld.append(super.toString());

        bld.append("Local de estágio:"); bld.append(this.getLocalDeEstagio()); bld.append(System.lineSeparator());
        bld.append("\nProfessor orientador:"); bld.append(responsavel.toString()); bld.append(System.lineSeparator());


     return bld.toString();
    }
}
