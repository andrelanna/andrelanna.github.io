import Exceptions.*;

import javax.swing.*;
import java.io.IOException;
import java.text.ParseException;
import java.util.InputMismatchException;

/**
 * Sistema de cadastros de alunos, professores, disciplinas e turmas de uma universidade:
 * Alunos, professores, disciplinas e turmas.
 *
 * Não devem ser aceitos casos em que alguma informação esteha faltando, em qualquer uma das classes que compõem esse
 * projeto. Criar a excessão InformaçãoFaltanteException que deve ser tratado no programa principal, ou seja, na main()
 * e informar pelo console em que classe  ela foi lançada.
 *
 * Excessões à criar (serem tratadas main da main()):
 *      - InformaçãoFaltanteException (caso algum atributo, de qualquer classe, não possua uma informação associada)
 *      - OrientadorNaoAtribuidoException (caso um aluno de pós não tenha um professor atribuído à ele. Informar pelo
 *      JOptionPane os dados do aluno cujo cadastro lançou a excessão)
 *      - ProfessorNaoAtribuidoException
 *      - DisciplinaNaoAtribuidaException
 *
 */

// TODO InformaçãoFaltanteException *
// TODO OrientadorNaoAtribuidoException *
// TODO DisciplinaNaoAtribuidaException *
// TODO ProfessorNaoAtribuidoException *
// TODO diagrama de classes e as classes de exceção implementadas em Java
// TODO toString()'s

public class Main {

    public static void main(String[] args) {
        String menu = Menus.menuPrincipal();

        int opcaomenu = 0;

        do{
            System.out.print(menu);

            try {
                opcaomenu = AcoesMenus.escolhaMenu();
            } catch (OpcaoInvalidaException e){
                handleOpcaoInvalidaException(e);
                opcaomenu = -1;
            } catch (InputMismatchException e) {
                handleInputMismatchException(e);
                opcaomenu = 0;
            }

            if (opcaomenu == 1){
                try {
                    Menus.menuCadastrarAluno();
                } catch(ParseException e) {
                    handleParseException(e);
                    opcaomenu = -1;
                } catch (OpcaoInvalidaException e) {
                    handleOpcaoInvalidaException(e);
                    opcaomenu = -1;
                } catch (InputMismatchException e) {
                    handleInputMismatchException(e);
                    opcaomenu = -1;
                } catch (IOException e) {
                    handleIOException(e);
                    opcaomenu = -1;
                } catch (InformacaoFaltanteException e) {
                    handleInformacaoFaltanteException(e);
                    opcaomenu = -1;
                } catch (OrientadorNaoAtribuidoException e) {
                    handleOrientadorNaoAtribuidoException(e);
                }

            } else if (opcaomenu == 2) {
                try {
                    Menus.menuCadastrarProfessor();
                } catch (ParseException e) {
                    handleParseException(e);
                    opcaomenu = -1;
                } catch (OpcaoInvalidaException e) {
                    handleOpcaoInvalidaException(e);
                    opcaomenu = -1;
                } catch (InputMismatchException e) {
                    handleInputMismatchException(e);
                    opcaomenu = -1;
                } catch (IOException e) {
                    handleIOException(e);
                    opcaomenu = -1;
                } catch (InformacaoFaltanteException e) {
                    handleInformacaoFaltanteException(e);
                    opcaomenu = -1;
                }

            } else if (opcaomenu == 3) {
                try {
                    Menus.menuCadastrarDisciplina();
                } catch (OpcaoInvalidaException e) {
                    e.printStackTrace();
                    opcaomenu = -1;
                } catch (IOException e) {
                    handleIOException(e);
                    opcaomenu = -1;
                } catch (InformacaoFaltanteException e) {
                    handleInformacaoFaltanteException(e);
                    opcaomenu = -1;
                }

            } else if (opcaomenu == 4) {
                try {
                    Menus.menuCadastrarTurma();
                } catch (IOException e) {
                    e.printStackTrace();
                    opcaomenu = -1;
                } catch (InformacaoFaltanteException e) {
                    handleInformacaoFaltanteException(e);
                    opcaomenu = -1;
                } catch (ProfessorNaoAtribuidoException e) {
                    handleProfessorNaoAtribuidoException(e);
                    opcaomenu = -1;
                } catch (DisciplinaNaoAtribuidaException e) {
                    handleDisciplinaNaoAtribuidaException(e);
                    opcaomenu = -1;
                }
            } else if (opcaomenu == 5) {
                try {
                    Menus.menuCadastrarEstagio();
                } catch (InformacaoFaltanteException e) {
                    handleInformacaoFaltanteException(e);
                    opcaomenu = -1;
                } catch (ProfessorNaoAtribuidoException e) {
                    handleProfessorNaoAtribuidoException(e);
                    opcaomenu = -1;
                } catch (IOException e) {
                    handleIOException(e);
                    opcaomenu = -1;
                }
            }
        } while (opcaomenu != 0);

    }

    private static void handleInformacaoFaltanteException(InformacaoFaltanteException e){
        JOptionPane.showMessageDialog(null, "InformacaoFaltanteException. Cadastro não pode ser feito com campos em branco. Cancelando cadastro.");
        e.printStackTrace();
    }

    private static void handleIOException(IOException e) {
        JOptionPane.showMessageDialog(null, "IOException. Registro falhou!");
        e.printStackTrace();
    }

    private static void handleOpcaoInvalidaException(OpcaoInvalidaException e) {
        JOptionPane.showMessageDialog(null, "OpcaoInvalidaException. Essa opcao não é válida nesse menu.");
        e.printStackTrace();
    }

    private static void handleParseException(ParseException e) {
        JOptionPane.showMessageDialog(null,"ParseException. Data no formato invalido");
        e.printStackTrace();
    }

    private static void handleInputMismatchException(InputMismatchException e) {
        JOptionPane.showMessageDialog(null,"InputMismatchException. Opcao inválida.");
        e.printStackTrace();
    }

    private static void handleOrientadorNaoAtribuidoException(OrientadorNaoAtribuidoException e) {
        JOptionPane.showMessageDialog(null,
                "OrientadorNaoAtribuidoException. Aluno não pode ser cadastrado sem um professor orientador");
        e.printStackTrace();
    }

    private static void handleDisciplinaNaoAtribuidaException(DisciplinaNaoAtribuidaException e) {
        JOptionPane.showMessageDialog(null,
                "DisciplinaNaoAtribuidaException. A turma precisa de uma disciplina. Cancelando cadastro.");
        e.printStackTrace();
    }

    private static void handleProfessorNaoAtribuidoException(ProfessorNaoAtribuidoException e) {
        JOptionPane.showMessageDialog(null,
                "DisciplinaNaoAtribuidaException. A turma precisa de um professor. Cancelando cadastro.");
        e.printStackTrace();
    }
}
