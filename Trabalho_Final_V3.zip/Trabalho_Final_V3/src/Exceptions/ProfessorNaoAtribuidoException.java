package Exceptions;

/**
 * Created by Gustavo on 05/07/2017.
 */
public class ProfessorNaoAtribuidoException extends Exception{
    public ProfessorNaoAtribuidoException() {
        super("ProfessorNaoAtribuidoException. Turma sem professor atribuído. Cancelando cadastro.");
    }
}
