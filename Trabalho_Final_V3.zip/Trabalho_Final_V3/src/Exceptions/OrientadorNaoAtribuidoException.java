package Exceptions;

/**
 * Created by Gustavo on 05/07/2017.
 */
public class OrientadorNaoAtribuidoException extends Exception {
    public OrientadorNaoAtribuidoException () {
        super("OrientadorNaoAtribuidoException. Aluno sem professor orientador atribuído. Cancelando cadastro");
    }
}
