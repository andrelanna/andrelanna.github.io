package Exceptions;

/**
 * Created by Gustavo on 05/07/2017.
 */
public class DisciplinaNaoAtribuidaException extends Exception{
    public DisciplinaNaoAtribuidaException() {
        super("DisciplinaNaoAtribuidaException. Turma sem disciplina atribuída. Cancelando cadastro");
    }

}
