package Exceptions;

import java.util.InputMismatchException;

/**
 * Created by Gustavo on 03/07/2017.
 */
public class OpcaoInvalidaException extends Exception {
    public OpcaoInvalidaException() {super ("OpcaoInvalidaException. Essa opção é inválida. ");}
}
