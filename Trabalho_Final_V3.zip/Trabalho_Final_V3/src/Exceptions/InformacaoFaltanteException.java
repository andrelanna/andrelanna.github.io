package Exceptions;

import javax.swing.*;

/**
 * Created by Gustavo on 05/07/2017.
 */
public class InformacaoFaltanteException extends Exception {
    public InformacaoFaltanteException(){
        super("InformacaoFaltanteException. Cadastro não pode ser feito com campos em branco. Cancelando cadastro.");
    }
}
