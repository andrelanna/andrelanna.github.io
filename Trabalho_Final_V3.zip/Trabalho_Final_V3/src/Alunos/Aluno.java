package Alunos;

/**
 * Classe abstrata para declaração de características gerais de alunos
 */

public abstract class Aluno {
    private String nome;
    private int matricula;
    private int semestreIngresso;
    private int anoIngresso;


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public int getSemestreIngresso() {
        return semestreIngresso;
    }

    public void setSemestreIngresso(int semestreIngresso) {
        this.semestreIngresso = semestreIngresso;
    }

    public int getAnoIngresso() {
        return anoIngresso;
    }

    public void setAnoIngresso(int anoIngresso) {
        this.anoIngresso = anoIngresso;
    }

    public boolean hasEmptyField(){
        if (this.getNome().isEmpty() ||
                this.getMatricula() == 0 ||
                this.getSemestreIngresso() == 0 ||
                this.getAnoIngresso() == 0
        ){
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString(){
        StringBuilder bld = new StringBuilder();
        bld.append("Nome: "); bld.append(getNome()); bld.append(System.lineSeparator());
        bld.append("Matricula: "); bld.append(getMatricula()); bld.append(System.lineSeparator());
        bld.append("Semestre de ingresso: "); bld.append(getSemestreIngresso()); bld.append(System.lineSeparator());
        bld.append("Ano de ingresso: "); bld.append(getAnoIngresso()); bld.append(System.lineSeparator());

        return bld.toString();
    }
}
