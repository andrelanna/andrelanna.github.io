package Alunos;

import Alunos.PosGraduacao;

/**
 * Created by Gustavo on 28/06/2017.
 */
public class Especial extends PosGraduacao {
    private boolean taxaPaga;
    private String semestreCursado;

    public boolean isTaxaPaga() {
        return taxaPaga;
    }

    public void setTaxaPaga(boolean taxaPaga) {
        this.taxaPaga = taxaPaga;
    }

    public String getSemestreCursado() {
        return semestreCursado;
    }

    public void setSemestreCursado(String semestreCursado) {
        this.semestreCursado = semestreCursado;
    }

    @Override
    public boolean hasEmptyField(){
        if (super.hasEmptyField() ||
                this.getSemestreCursado().isEmpty()) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        StringBuilder bld = new StringBuilder();
    
        bld.append("Taxa paga:"); bld.append(this.isTaxaPaga());  bld.append(System.lineSeparator());
        bld.append("Semestre cursado:"); bld.append(this.getSemestreCursado());  bld.append(System.lineSeparator());
        bld.append(super.toString());


     return bld.toString();
    }
}
