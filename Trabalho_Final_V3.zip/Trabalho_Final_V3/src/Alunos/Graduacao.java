package Alunos;

import java.util.Date;

/**
 * Created by Gustavo on 28/06/2017.
 *
 * Classe para criação de alunos de graduação.
 */
public class Graduacao extends Aluno {
    private String formaIngresso;
    private String curso;
    private Date provavelDefesa;

    public Graduacao() {}

    public Graduacao(String nome, int matricula, int semestreIngresso, int anoIngresso, String formaIngresso, String curso, Date provavelDefesa) {
        this.setNome(nome);
        this.setMatricula(matricula);
        this.setSemestreIngresso(semestreIngresso);
        this.setAnoIngresso(anoIngresso);
        this.setFormaIngresso(formaIngresso);
        this.setCurso(curso);
        this.setProvavelDefesa(provavelDefesa);
    }

    public String getFormaIngresso() {
        return formaIngresso;
    }

    public void setFormaIngresso(String formaIngresso) {
        this.formaIngresso = formaIngresso;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public Date getProvavelDefesa() {
        return provavelDefesa;
    }

    public void setProvavelDefesa(Date provavelDefesa) {
        this.provavelDefesa = provavelDefesa;
    }

    @Override
    public boolean hasEmptyField(){
        if (super.hasEmptyField() ||
                this.getFormaIngresso().isEmpty() ||
                this.getCurso().isEmpty() ||
                this.getProvavelDefesa() == null) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        StringBuilder bld = new StringBuilder();
        bld.append(super.toString());

        bld.append("Forma ingresso: "); bld.append(this.getFormaIngresso()); bld.append(System.lineSeparator());
        bld.append("Curso: "); bld.append(this.getCurso()); bld.append(System.lineSeparator());
        bld.append("Provavel defesa: "); bld.append(this.getProvavelDefesa()); bld.append(System.lineSeparator());


     return bld.toString();
    }
}
