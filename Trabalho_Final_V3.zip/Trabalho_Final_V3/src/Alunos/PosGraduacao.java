package Alunos;

import Alunos.Aluno;
import Professores.Professor;

import java.util.Date;

/**
 * Created by Gustavo on 28/06/2017.
 */
public class PosGraduacao extends Aluno {
    private int semestreQualificacao;
    private Date provavelDefesa;
    private Professor orientador;

    public int getSemestreQualificacao() {
        return semestreQualificacao;
    }

    public void setSemestreQualificacao(int semestreQualificacao) {
        this.semestreQualificacao = semestreQualificacao;
    }

    public Date getProvavelDefesa() {
        return provavelDefesa;
    }

    public void setProvavelDefesa(Date provavelDefesa) {
        this.provavelDefesa = provavelDefesa;
    }

    public Professor getOrientador() {
        return orientador;
    }

    public void setOrientador(Professor orientador) {
        this.orientador = orientador;
    }

    public boolean hasEmptyField(){
        if (super.hasEmptyField() ||
                this.getOrientador() == null ||
                this.getSemestreQualificacao() == 0 ||
                this.getProvavelDefesa() == null) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        StringBuilder bld = new StringBuilder();
        bld.append(super.toString());

        bld.append("Semestre de qualificação:"); bld.append(this.getSemestreQualificacao());  bld.append(System.lineSeparator());
        bld.append("Provavel defesa:"); bld.append(this.getProvavelDefesa());  bld.append(System.lineSeparator());
        bld.append("Professor orientador"); bld.append(System.lineSeparator());
        bld.append(this.orientador.toString());  bld.append(System.lineSeparator());

     return bld.toString();
    }
}
