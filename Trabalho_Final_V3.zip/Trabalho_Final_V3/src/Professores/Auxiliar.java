package Professores;

/**
 * Created by Gustavo on 30/06/2017.
 */
public class Auxiliar extends Professor {
    private String graduacao;
    private int anoGraduacao;

    public String getGraduacao() {
        return graduacao;
    }

    public void setGraduacao(String graduacao) {
        this.graduacao = graduacao;
    }

    public int getAnoGraduacao() {
        return anoGraduacao;
    }

    public void setAnoGraduacao(int anoGraduacao) {
        this.anoGraduacao = anoGraduacao;
    }

    @Override
    public boolean hasEmptyField(){
        if (super.hasEmptyField() ||
                this.getGraduacao().isEmpty() ||
                this.getAnoGraduacao() == 0) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        StringBuilder bld = new StringBuilder();
        bld.append(super.toString());

        bld.append("Graduação: "); bld.append(this.getGraduacao()); bld.append(System.lineSeparator());
        bld.append("Ano de graduação: "); bld.append(this.getAnoGraduacao()); bld.append(System.lineSeparator());
        

     return bld.toString();
    }
}
