package Professores;

import java.util.Date;

/**
 * Created by Gustavo on 30/06/2017.
 */
public class Titular extends Associado {
    private Date concurso;
    private Date dataDeAdmissao;

    public Date getConcurso() {
        return concurso;
    }

    public void setConcurso(Date concurso) {
        this.concurso = concurso;
    }

    public Date getDataDeAdmissao() {
        return dataDeAdmissao;
    }

    public void setDataDeAdmissao(Date dataDeAdmissao) {
        this.dataDeAdmissao = dataDeAdmissao;
    }

    @Override
    public boolean hasEmptyField(){
        if (super.hasEmptyField() ||
                this.getConcurso() == null ||
                this.getDataDeAdmissao() == null) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        StringBuilder bld = new StringBuilder();
        bld.append(super.toString());

        bld.append("Concurso: "); bld.append(this.getConcurso()); bld.append(System.lineSeparator());
        bld.append("Data de admissão: "); bld.append(this.getDataDeAdmissao()); bld.append(System.lineSeparator());
        

     return bld.toString();
    }
}
