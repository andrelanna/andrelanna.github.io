package Professores;

/**
 * Created by Gustavo on 30/06/2017.
 */
public class Adjunto extends Assistente {
    private String tituloTese;
    private String Doutorado;
    private int anoDoutorado;

    public String getTituloTese() {
        return tituloTese;
    }

    public void setTituloTese(String tituloTese) {
        this.tituloTese = tituloTese;
    }

    public String getDoutorado() {
        return Doutorado;
    }

    public void setDoutorado(String doutorado) {
        Doutorado = doutorado;
    }

    public int getAnoDoutorado() {
        return anoDoutorado;
    }

    public void setAnoDoutorado(int anoDoutorado) {
        this.anoDoutorado = anoDoutorado;
    }

    @Override
    public boolean hasEmptyField(){
        if (super.hasEmptyField() ||
                this.getTituloTese().isEmpty() ||
                this.getDoutorado().isEmpty() ||
                this.getAnoDoutorado() == 0) {
            return true;
        } else {
            return false;
        }
    }
    
    @Override
    public String toString() {
        StringBuilder bld = new StringBuilder();
        bld.append(super.toString());

        bld.append("Doutorado: "); bld.append(this.getDoutorado()); bld.append(System.lineSeparator());
        bld.append("Ano do Doutorado: "); bld.append(this.getAnoDoutorado()); bld.append(System.lineSeparator());
        bld.append("Título da Tese: "); bld.append(this.getTituloTese()); bld.append(System.lineSeparator());
        

     return bld.toString();
    }
}
