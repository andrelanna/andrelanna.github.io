package Professores;

/**
 * Created by Gustavo on 30/06/2017.
 */
public class Assistente extends Auxiliar {
    private String tituloDissertacao;
    private String mestrado;
    private int anoMestrado;

    public String getMestrado() {
        return mestrado;
    }

    public void setMestrado(String mestrado) {
        this.mestrado = mestrado;
    }

    public int getAnoMestrado() {
        return anoMestrado;
    }

    public void setAnoMestrado(int anoMestrado) {
        this.anoMestrado = anoMestrado;
    }

    public String getTituloDissertacao() {
        return tituloDissertacao;
    }

    public void setTituloDissertacao(String tituloDissertacao) {
        this.tituloDissertacao = tituloDissertacao;
    }

    @Override
    public boolean hasEmptyField(){
        if (super.hasEmptyField() ||
                this.getTituloDissertacao().isEmpty() ||
                this.getMestrado().isEmpty() ||
                this.getAnoMestrado() == 0) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        StringBuilder bld = new StringBuilder();
        bld.append(super.toString());

        bld.append("Mestrado: "); bld.append(this.getMestrado()); bld.append(System.lineSeparator());
        bld.append("Ano do mestrado: "); bld.append(this.getAnoMestrado()); bld.append(System.lineSeparator());
        bld.append("Título da dissertação: "); bld.append(this.getTituloDissertacao()); bld.append(System.lineSeparator());
        

     return bld.toString();
    }
}
