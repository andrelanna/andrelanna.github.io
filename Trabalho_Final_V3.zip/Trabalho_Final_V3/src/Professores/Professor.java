package Professores;

/**
 * Created by Gustavo on 28/06/2017.
 */

public class Professor {
    private String nome;
    private String formacao;
    private int matriculaSiape;
    private int matriculaFUB;
    private float salario;

    public String getFormacao() {
        return formacao;
    }

    public void setFormacao(String formacao) {
        this.formacao = formacao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getMatriculaSiape() {
        return matriculaSiape;
    }

    public void setMatriculaSiape(int matriculaSiape) {
        this.matriculaSiape = matriculaSiape;
    }

    public int getMatriculaFUB() {
        return matriculaFUB;
    }

    public void setMatriculaFUB(int matriculaFUB) {
        this.matriculaFUB = matriculaFUB;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public boolean hasEmptyField(){
        if (this.getNome().isEmpty() ||
                this.getFormacao().isEmpty() ||
                this.getMatriculaSiape() == 0 ||
                this.getMatriculaFUB() == 0 ||
                this.getSalario() == 0) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString(){
        StringBuilder bld = new StringBuilder();
        bld.append("Nome: "); bld.append(getNome()); bld.append(System.lineSeparator());
        bld.append("Formação: "); bld.append(getFormacao()); bld.append(System.lineSeparator());
        bld.append("Matrícula Siape: "); bld.append(getMatriculaSiape()); bld.append(System.lineSeparator());
        bld.append("Matrícula FUB: "); bld.append(getMatriculaFUB()); bld.append(System.lineSeparator());
        bld.append("Salário: "); bld.append(getSalario()); bld.append(System.lineSeparator());

        return bld.toString();
    }
}
