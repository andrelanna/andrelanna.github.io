package Professores;

/**
 * Created by Gustavo on 30/06/2017.
 */
public class Associado extends Adjunto {
    private String areaDePesquisa;

    public String getAreaDePesquisa() {
        return areaDePesquisa;
    }

    public void setAreaDePesquisa(String areaDePesquisa) {
        this.areaDePesquisa = areaDePesquisa;
    }

    @Override
    public boolean hasEmptyField(){
        if (super.hasEmptyField() ||
                this.getAreaDePesquisa().isEmpty()) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        StringBuilder bld = new StringBuilder();
        bld.append(super.toString());

        bld.append("Área de pesquisa: "); bld.append(this.getAreaDePesquisa()); bld.append(System.lineSeparator());

     return bld.toString();
    }
}
