import java.util.InputMismatchException;
import java.util.Scanner;

import Exceptions.OpcaoInvalidaException;

public class AcoesMenus {
	
	static Scanner input = new Scanner(System.in);

    static int escolhaMenu() throws OpcaoInvalidaException, InputMismatchException {
        int opcao = 0;

        opcao = input.nextInt();
        if (opcao < 0 || opcao > 5) {
            throw new OpcaoInvalidaException();
        }

        return opcao;
    }

    static int escolhaAluno() throws OpcaoInvalidaException, InputMismatchException {
        int opcao = 0;

        opcao = input.nextInt();
        if (opcao < 0 || opcao > 2) {
            throw new OpcaoInvalidaException();
        }

        return opcao;
    }
    
    static int escolhaAlunoPosGrad()  throws OpcaoInvalidaException, InputMismatchException {
        int opcao = 0;

        opcao = input.nextInt();
        if (opcao < 0 || opcao > 2) {
            throw new OpcaoInvalidaException();
        }

        return opcao;
    }
    
	static int escolhaProfessor() throws OpcaoInvalidaException, InputMismatchException {
        int opcao = 0;

        opcao = input.nextInt();
        if (opcao < 0 || opcao > 5) {
            throw new OpcaoInvalidaException();
        }

        return opcao;
	}
    
    static int escolhaDiscplina() throws OpcaoInvalidaException, InputMismatchException {
        int opcao = 0;

        opcao = input.nextInt();
        if (opcao < 0 || opcao > 2) {
            throw new OpcaoInvalidaException();
        }

        return opcao;
    }

}
