package att3quest2;

public class App{
    public static void main(String []args){
        Janela p = new Janela();
    }
}