package att3quest2;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

class Janela extends JFrame{
   
    JPanel painel1,
           painel2;
    
    JLabel lbVa,
           lbJuros,
           lbTempo,
           lbResultado;
   
    JTextField txVa,
               txJuros,
               txTempo;
    
    JButton btCalcular;
   
    Janela(){
        
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(500,250);
        this.setLayout(new GridLayout(3,1));
        
        //Labels
        lbVa= new JLabel("Valor inicial");
        lbJuros = new JLabel("Juros");
        lbTempo = new JLabel("Tempo em meses");
        lbResultado = new JLabel("Esperando o Cálculo");
        
        //TextField
        txVa = new JTextField();
        txJuros = new JTextField();
        txTempo = new JTextField();
        
        //Botão
        btCalcular = new JButton("Calcular");
        btCalcular.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                    JFrame tela = new JFrame("Relatório de Atividades");
                    int n =Integer.parseInt(txTempo.getText());
                    float j = Float.parseFloat(txJuros.getText())/100;
                    float p = Float.parseFloat(txVa.getText());
                    float resultado;
                    
                    tela.setLayout(new GridLayout(12,((n%12==0)? 1 : n%12)));
                    for(int i=1; i<=n; ++i){
                        JLabel texto = new JLabel();
                        resultado =(float) ((1+j)*((Math.pow(1+j,n)-1)/j)*p);
                        String k ="Mês "+i+": "+'\n';
                        k+=Float.toString(resultado);
                        k+="\n";
                        texto.setText(k);
                        tela.add(texto);
                    }
                     tela.setSize(500,400);
                     tela.setVisible(true);
                    
                    }
                   
        });
        
        //Painel
        painel1 = new JPanel();   
        painel2= new JPanel();
        
        painel1.setLayout(new GridLayout(3,2));
        painel1.setSize(100,100);
        
        painel1.add(lbVa);
        painel1.add(txVa);
        painel1.add(lbJuros);
        painel1.add(txJuros);
        painel1.add(lbTempo);
        painel1.add(txTempo);
        
        painel2.add(btCalcular);
        painel2.setSize(50,50);
        
        add(painel1);
        add(painel2);
        this.setVisible(true);
    }
}