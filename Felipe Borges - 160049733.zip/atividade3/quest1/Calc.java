package quest1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

class Calc implements ActionListener{
    Janela tela;
    public Calc(Janela in){
        tela=in;
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        boolean a = tela.txValorFuturo.getText().isEmpty();
        boolean b = tela.txValorPresente.getText().isEmpty();
        boolean c = tela.txJuros.getText().isEmpty();
        boolean d = tela.txMeses.getText().isEmpty();
        if(a && !b && !c && !d){
            float va = Float.parseFloat(tela.txValorPresente.getText());
            float taxa = Float.parseFloat(tela.txJuros.getText())/100;
            int meses = Integer.parseInt(tela.txMeses.getText());
            float resultado=(float)(va *Math.pow(1+taxa,meses));
            tela.txValorFuturo.setText(Float.toString(resultado));
            
            
        }else if(!a && b && !c && !d){
            float m = Float.parseFloat(tela.txValorFuturo.getText());
            float juros = Float.parseFloat(tela.txJuros.getText())/100;
            int meses = Integer.parseInt(tela.txMeses.getText());
            float resultado = (float)(m/Math.pow(1+juros,meses));
            tela.txValorPresente.setText(Float.toString(resultado));
        }else if(!a && !b && c && !d){
             float m = Float.parseFloat(tela.txValorFuturo.getText());
             float va = Float.parseFloat(tela.txValorPresente.getText());
             int meses = Integer.parseInt(tela.txMeses.getText());
             float resultado = (float)(Math.pow(m/va,(1.0/meses)) -1 )*100;
             tela.txJuros.setText(Float.toString(resultado));
           
        }else if(!a && !b && !c && d){
             float m = Float.parseFloat(tela.txValorFuturo.getText());
             float va = Float.parseFloat(tela.txValorPresente.getText());
             float juros = Float.parseFloat(tela.txJuros.getText())/100;
             int resultado = (int) Math.ceil((Math.log(m/va)/Math.log(1+juros)));
             tela.txMeses.setText(Integer.toString(resultado));
              
        }else {
            tela.txValorFuturo.setText("Error");
            tela.txValorPresente.setText("Error");
            tela.txJuros.setText("Error");
            tela.txMeses.setText("Error");
        }
    }
    
}