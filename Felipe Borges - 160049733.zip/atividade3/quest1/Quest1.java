package quest1;

public class Quest1{
    public static void main(String []args){
        Janela novo = new Janela();
    }
}