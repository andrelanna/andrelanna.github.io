package quest1;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Janela extends JFrame{
    
    JButton btCalcular,
            btLimpar;
    
    JTextField txValorFuturo,
               txValorPresente,
               txJuros,
               txMeses;
    
    JLabel lbValorFuturo,
           lbValorPresente,
           lbJuros,
           lbMeses;
    
    Janela(){
        this.setTitle("Questão 1 da Atividade 3");
        this.setLayout(new GridLayout(5,2));
        this.setSize(500,300);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        btCalcular = new JButton("Calcular");
        btLimpar = new JButton("Limpar");
        
        //limpar é pequeno então colocarei na classe principal
        btLimpar.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                txValorFuturo.setText("");
                txValorPresente.setText("");
                txJuros.setText("");
                txMeses.setText("");
            }
            
        });
        
        btCalcular.addActionListener(new Calc(this));
        
        lbValorFuturo = new JLabel("Valor Futuro");
        lbValorPresente = new JLabel("Valor atual");
        lbJuros = new JLabel("Juros(%)");
        lbMeses = new JLabel("Meses");
        
        txValorFuturo = new JTextField();
        txValorPresente = new JTextField();
        txJuros = new JTextField();
        txMeses = new JTextField();
        
        add(lbValorFuturo);
        add(txValorFuturo);
        add(lbValorPresente);
        add(txValorPresente);
        add(lbJuros);
        add(txJuros);
        add(lbMeses);
        add(txMeses);
        add(btCalcular);
        add(btLimpar);
        this.setVisible(true);
        
        
    }
}
