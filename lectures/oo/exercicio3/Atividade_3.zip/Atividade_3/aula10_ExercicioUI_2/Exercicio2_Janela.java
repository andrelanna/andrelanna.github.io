package aula10_ExercicioUI_2;

import javax.swing.*;
import java.awt.*;

/**
 * Created by Gustavo on 19/05/2017.
 */
public class Exercicio2_Janela extends JFrame {
    JTextField txtTaxa, txtDeposito, txtMeses;
    JLabel lblTaxa, lblDeposito, lblMeses;
    JButton btnCalcular, btnLimpar;
    JPanel panelUp, panelDown;
    GridLayout grid;
    public Exercicio2_Janela() {
        setTitle("Atividade 3 - Exercício 2");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(400, 300);

        setLayout(new GridLayout(2, 1));

        panelUp = new JPanel();
        panelUp.setLayout(new GridLayout(5, 2));
        add(panelUp);

        txtTaxa = new JTextField();
        txtDeposito= new JTextField();
        txtMeses = new JTextField();
        lblTaxa = new JLabel("Taxa de juros:");
        lblDeposito = new JLabel("Deposito:");
        lblMeses = new JLabel("Meses:");

        btnCalcular = new JButton("Calcular");
        btnLimpar = new JButton("Limpar");

        panelUp.add(lblDeposito);
        panelUp.add(txtDeposito);
        panelUp.add(lblTaxa);
        panelUp.add(txtTaxa);
        panelUp.add(lblMeses);
        panelUp.add(txtMeses);
        panelUp.add(btnCalcular);
        panelUp.add(btnLimpar);
        panelUp.add(new JLabel("Valores por mes:"));

        panelDown = new JPanel();
        grid = new GridLayout(5,1);

        panelDown.setLayout(grid);
        add(panelDown);

        btnCalcular.addActionListener(new CalcularListener(this));
        btnLimpar.addActionListener( new LimparListener(this));

        setVisible(true);
    }

}
