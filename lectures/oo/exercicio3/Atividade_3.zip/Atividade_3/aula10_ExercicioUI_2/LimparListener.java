package aula10_ExercicioUI_2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by Gustavo on 19/05/2017.
 */
public class LimparListener implements ActionListener {
    Exercicio2_Janela j;
    public LimparListener(Exercicio2_Janela janela) {
        j = janela;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        j.txtMeses.setText("");
        j.txtTaxa.setText("");
        j.txtDeposito.setText("");

        j.panelDown.removeAll();
        j.panelDown.repaint();
    }
}
