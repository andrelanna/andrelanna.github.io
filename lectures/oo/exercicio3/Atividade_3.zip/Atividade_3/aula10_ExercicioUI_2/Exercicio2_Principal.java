package aula10_ExercicioUI_2;

/**
 * Created by Gustavo on 19/05/2017.
 */
public class Exercicio2_Principal {

    public static void main(String[] args) {
        Exercicio2_Janela janela = new Exercicio2_Janela();
    }

}
