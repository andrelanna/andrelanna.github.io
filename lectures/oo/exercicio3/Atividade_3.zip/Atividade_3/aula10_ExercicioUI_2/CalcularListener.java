package aula10_ExercicioUI_2;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by Gustavo on 19/05/2017.
 */
public class CalcularListener implements ActionListener {
    Exercicio2_Janela j;

    public CalcularListener(Exercicio2_Janela janela){
        j = janela;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        float taxa = 0, deposito = 0, meses = 0, valor = 0;

        j.panelDown.removeAll();
        j.panelDown.repaint();

        String strTaxa = j.txtTaxa.getText();
        String strDeposito = j.txtDeposito.getText();
        String strMeses = j.txtMeses.getText();

        if (!strTaxa.equals(""))
            taxa = Float.parseFloat(strTaxa);
        if (!strDeposito.equals(""))
            deposito = Float.parseFloat(strDeposito);
        if (!strMeses.equals(""))
            meses = Float.parseFloat(strMeses);

        taxa /= 100;

        for (int i = 0; i < meses; i++){
            valor = ((1 + taxa) * valor) + deposito;
            j.panelDown.add(new JLabel(Float.toString(valor)));
        }
        j.setVisible(true);
    }
}
