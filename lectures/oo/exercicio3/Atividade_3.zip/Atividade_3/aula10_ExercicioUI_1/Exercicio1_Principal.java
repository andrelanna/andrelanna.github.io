package aula10_ExercicioUI_1;

/**
 * Created by Gustavo on 19/05/2017.
 */
public class Exercicio1_Principal {

    public static void main(String[] args) {
        Exercicio1_Janela janela = new Exercicio1_Janela();
    }
}
