package aula10_ExercicioUI_1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by Gustavo on 19/05/2017.
 */
public class CalcularListener implements ActionListener {
    Exercicio1_Janela j;

    public CalcularListener(Exercicio1_Janela janela) {
        j = janela;
    }

    @Override
    public void actionPerformed (ActionEvent event) {
        int camposVazios = 0;
        float valorFuturo = 0;
        float valorPresente = 0;
        float taxa = 0;
        float meses = 0;

        String strValorFuturo = j.txtValorFuturo.getText();
        String strValorPresente = j.txtValorPresente.getText();
        String strTaxa = j.txtTaxa.getText();
        String strTempo = j.txtMeses.getText();

        if(strValorFuturo.equals(""))
            camposVazios++;
        if(strValorPresente.equals(""))
            camposVazios++;
        if(strTaxa.equals(""))
            camposVazios++;
        if(strTempo.equals(""))
            camposVazios++;

        if (!strValorFuturo.equals(""))
            valorFuturo = Float.parseFloat(j.txtValorFuturo.getText());
        if (!strValorPresente.equals(""))
             valorPresente = Float.parseFloat(j.txtValorPresente.getText());
        if (!strTaxa.equals(""))
             taxa = Float.parseFloat(j.txtTaxa.getText());
        if (!strTempo.equals(""))
             meses = Float.parseFloat(j.txtMeses.getText());

        taxa /= 100;

        if (strValorFuturo.equals("")){
            valorFuturo = (float)(valorPresente * Math.pow((1 + taxa), meses));
            j.txtValorFuturo.setText(Float.toString(valorFuturo));
        }
        else if (strValorPresente.equals("")){
            valorPresente = (float)(valorFuturo/Math.pow((1 + taxa), meses));
            j.txtValorPresente.setText(Float.toString(valorPresente));
        }
        else if (strTaxa.equals("")){
            taxa = (float) (100 * (Math.pow((valorFuturo/valorPresente), (1/meses)) - 1));
            j.txtTaxa.setText(Float.toString(taxa));
        }
        else if (strTempo.equals("")){
            meses = (float) (Math.log(valorFuturo/valorPresente)/Math.log(1 + taxa));
            j.txtMeses.setText(Float.toString(meses));
        }
    }
}
