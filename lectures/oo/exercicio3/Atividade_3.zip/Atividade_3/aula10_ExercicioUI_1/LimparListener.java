package aula10_ExercicioUI_1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by Gustavo on 19/05/2017.
 */
public class LimparListener implements ActionListener {
    Exercicio1_Janela j;

    public LimparListener(Exercicio1_Janela janela) { j = janela; }

    public void actionPerformed(ActionEvent e){
        j.txtValorFuturo.setText("");
        j.txtValorPresente.setText("");
        j.txtTaxa.setText("");
        j.txtMeses.setText("");
    }
}
