package aula10_ExercicioUI_1;

import javax.swing.*;
import java.awt.*;

/**
 * Created by Gustavo on 19/05/2017.
 */
public class Exercicio1_Janela extends JFrame{
    JLabel lblAviso, lblFormula, lblValorFormula,
    lblValorFuturo, lblValorPresente,
    lblTaxa, lblMeses;

    JTextField txtValorFuturo, txtValorPresente,
    txtTaxa, txtMeses;

    JButton btnCalcular, btnLimpar;

    public Exercicio1_Janela() {
        setTitle("Atividade 3 - Exercício 1");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 4));
        setSize(600,200);

        lblAviso = new JLabel();
        lblFormula = new JLabel(" Fórmula: ", SwingConstants.RIGHT);
        lblFormula.setOpaque(true);
        lblFormula.setBackground(Color.gray);
        lblFormula.setForeground(Color.white);
        lblValorFormula = new JLabel("VF = VA(1 + i)^n", SwingConstants.LEFT);
        lblValorFormula.setOpaque(true);
        lblValorFormula.setBackground(Color.gray);
        lblValorFormula.setForeground(Color.white);
        lblValorFuturo = new JLabel("Valor Futuro:", SwingConstants.CENTER);
        lblValorPresente = new JLabel("Valor presente:", SwingConstants.CENTER);
        lblTaxa = new JLabel("Taxa de Juros:", SwingConstants.CENTER);
        lblMeses = new JLabel("Tempo (Em meses):", SwingConstants.CENTER);

        txtValorFuturo = new JTextField();
        txtValorPresente = new JTextField();
        txtTaxa = new JTextField();
        txtMeses = new JTextField();

        btnCalcular = new JButton("Calcular");
        btnLimpar = new JButton("Limpar");

        add(lblAviso);
        add(lblFormula);
        add(lblValorFormula);
        add(new JPanel());
        add(lblValorFuturo);
        add(lblValorPresente);
        add(lblTaxa);
        add(lblMeses);
        add(txtValorFuturo);
        add(txtValorPresente);
        add(txtTaxa);
        add(txtMeses);
        add(new JPanel());
        add(btnCalcular);
        add(btnLimpar);

        btnCalcular.addActionListener(new CalcularListener(this));
        btnLimpar.addActionListener(new LimparListener(this));

        this.setVisible(true);
    }
}
