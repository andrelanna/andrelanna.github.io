package introducaoCollections;

public class Aluno {
	String nome;
	int matricula;
	
	public Aluno() {
	}
	
	public Aluno(String nome, int matricula) {
		this();
		this.nome = nome;
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public int getMatricula() {
		return this.matricula;
	}
}
