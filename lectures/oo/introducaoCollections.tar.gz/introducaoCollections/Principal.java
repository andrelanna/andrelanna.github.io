package introducaoCollections;

public class Principal {
	

	public static void main(String[] args) {
		Turma t = new Turma(13, "Andre");
		
		Aluno a = null; 
		for (int i=1; i<=5; i++) {
			a = new Aluno("Aluno " + i, i);
			boolean resposta = t.matricular(a);
			System.out.println(a.getNome() +
				   " foi matriculado?" +
			       (resposta ? "sim" : "nao"));
		}
		
		a = t.pesquisarPorMatricula(3);
		System.out.println(a);
		a = t.pesquisarPorMatricula(10);
		System.out.println(a);
	}

}
