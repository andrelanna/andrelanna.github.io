package introducaoCollections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Turma {
	
	private int codigo;
	private String professor;
	
	private Set <Aluno> alunos;

	private Turma() {
		alunos = new HashSet<Aluno>();
	}
	
	public Turma(int codigo, String professor) {
		this();
		this.codigo = codigo;
		this.professor = professor;
	}
	
	public boolean matricular(Aluno a) {
		boolean resposta = false;
		resposta = alunos.add(a);
		return resposta;
	}

	public Aluno pesquisarPorMatricula(int i) {
		Aluno resposta = null;
		
		Iterator<Aluno> elementos = alunos.iterator();
		while (elementos.hasNext()){
			Aluno a = elementos.next();
			if (i == a.getMatricula()) {
				resposta = a;
				break;
			}
		}
		
		return resposta;
	}
}
