import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class UI {

	private JFrame frame;
	private JTextField txtOp1;
	private JTextField txtOp2;
	private JTextField txtResultado;

	private Calculadora calc;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UI window = new UI();
					window.frame.setVisible(true);
				} catch (ArithmeticException e2) {
					JOptionPane.showMessageDialog(null,
							"capturei excecao em main()" + e2.getMessage());
				} catch (NumberFormatException e2) {
					JOptionPane.showMessageDialog(null,
							"Valor invalido para algum operando.");
					e2.printStackTrace();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public UI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] { 0, 0, 0 };
		gridBagLayout.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0 };
		gridBagLayout.columnWeights = new double[] { 0.0, 0.0, Double.MIN_VALUE };
		gridBagLayout.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
				0.0, Double.MIN_VALUE };
		frame.getContentPane().setLayout(gridBagLayout);

		JLabel lblOperando = new JLabel("Operando 1:");
		GridBagConstraints gbc_lblOperando = new GridBagConstraints();
		gbc_lblOperando.anchor = GridBagConstraints.EAST;
		gbc_lblOperando.insets = new Insets(0, 0, 5, 5);
		gbc_lblOperando.gridx = 0;
		gbc_lblOperando.gridy = 0;
		frame.getContentPane().add(lblOperando, gbc_lblOperando);

		txtOp1 = new JTextField();
		txtOp1.setText("op1");
		GridBagConstraints gbc_txtOp1 = new GridBagConstraints();
		gbc_txtOp1.insets = new Insets(0, 0, 5, 0);
		gbc_txtOp1.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtOp1.gridx = 1;
		gbc_txtOp1.gridy = 0;
		frame.getContentPane().add(txtOp1, gbc_txtOp1);
		txtOp1.setColumns(10);

		JLabel lblOperando_1 = new JLabel("Operando 2:");
		GridBagConstraints gbc_lblOperando_1 = new GridBagConstraints();
		gbc_lblOperando_1.anchor = GridBagConstraints.EAST;
		gbc_lblOperando_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblOperando_1.gridx = 0;
		gbc_lblOperando_1.gridy = 1;
		frame.getContentPane().add(lblOperando_1, gbc_lblOperando_1);

		txtOp2 = new JTextField();
		txtOp2.setText("op2");
		GridBagConstraints gbc_txtOp2 = new GridBagConstraints();
		gbc_txtOp2.insets = new Insets(0, 0, 5, 0);
		gbc_txtOp2.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtOp2.gridx = 1;
		gbc_txtOp2.gridy = 1;
		frame.getContentPane().add(txtOp2, gbc_txtOp2);
		txtOp2.setColumns(10);

		JLabel lblResultado = new JLabel("Resultado");
		GridBagConstraints gbc_lblResultado = new GridBagConstraints();
		gbc_lblResultado.anchor = GridBagConstraints.EAST;
		gbc_lblResultado.insets = new Insets(0, 0, 5, 5);
		gbc_lblResultado.gridx = 0;
		gbc_lblResultado.gridy = 2;
		frame.getContentPane().add(lblResultado, gbc_lblResultado);

		txtResultado = new JTextField();
		txtResultado.setText("resultado");
		GridBagConstraints gbc_txtResultado = new GridBagConstraints();
		gbc_txtResultado.insets = new Insets(0, 0, 5, 0);
		gbc_txtResultado.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtResultado.gridx = 1;
		gbc_txtResultado.gridy = 2;
		frame.getContentPane().add(txtResultado, gbc_txtResultado);
		txtResultado.setColumns(10);

		JButton button = new JButton("+");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				int op1 = Integer.parseInt(txtOp1.getText());
				int op2 = Integer.parseInt(txtOp2.getText());
				calc = new Calculadora(op1, op2);
				int resultado = calc.soma();
				txtResultado.setText(Integer.toString(resultado));
			}
		});
		GridBagConstraints gbc_button = new GridBagConstraints();
		gbc_button.insets = new Insets(0, 0, 5, 5);
		gbc_button.gridx = 0;
		gbc_button.gridy = 4;
		frame.getContentPane().add(button, gbc_button);

		JButton button_1 = new JButton("-");
		GridBagConstraints gbc_button_1 = new GridBagConstraints();
		gbc_button_1.insets = new Insets(0, 0, 5, 0);
		gbc_button_1.gridx = 1;
		gbc_button_1.gridy = 4;
		frame.getContentPane().add(button_1, gbc_button_1);

		JButton button_2 = new JButton("*");
		GridBagConstraints gbc_button_2 = new GridBagConstraints();
		gbc_button_2.insets = new Insets(0, 0, 5, 5);
		gbc_button_2.gridx = 0;
		gbc_button_2.gridy = 5;
		frame.getContentPane().add(button_2, gbc_button_2);

		JButton button_3 = new JButton("/");
		button_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				try {
					calcularDivisao();
				} catch (NumberFormatException e1) {
					JOptionPane.showMessageDialog(
							null,
							"Excecao capturada em mousePressed: "
									+ e1.getMessage());
				} catch (DivisaoPorZeroException e3) {
					JOptionPane.showMessageDialog(null,
							"Capturei excecao em mousePressed():" + e3.getMessage());
					e3.printStackTrace();
				} catch (ArithmeticException e2) {
					JOptionPane.showMessageDialog(
							null,
							"Excecao capturada em mousePressed: "
									+ e2.getMessage());
					e2.printStackTrace();
				}
			}

			private void calcularDivisao() throws NumberFormatException,
					ArithmeticException, DivisaoPorZeroException {
				int op1 = -1;
				int op2 = -1;

				op1 = Integer.parseInt(txtOp1.getText());
				op2 = Integer.parseInt(txtOp2.getText());

				calc = new Calculadora(op1, op2);
				int resultado;

				resultado = calc.divisao();

				txtResultado.setText(Integer.toString(resultado));

			}
		});
		GridBagConstraints gbc_button_3 = new GridBagConstraints();
		gbc_button_3.insets = new Insets(0, 0, 5, 0);
		gbc_button_3.gridx = 1;
		gbc_button_3.gridy = 5;
		frame.getContentPane().add(button_3, gbc_button_3);

		JButton button_4 = new JButton("^");
		GridBagConstraints gbc_button_4 = new GridBagConstraints();
		gbc_button_4.insets = new Insets(0, 0, 0, 5);
		gbc_button_4.gridx = 0;
		gbc_button_4.gridy = 6;
		frame.getContentPane().add(button_4, gbc_button_4);

		JButton btnLog = new JButton("log10");
		GridBagConstraints gbc_btnLog = new GridBagConstraints();
		gbc_btnLog.gridx = 1;
		gbc_btnLog.gridy = 6;
		frame.getContentPane().add(btnLog, gbc_btnLog);
	}
}
