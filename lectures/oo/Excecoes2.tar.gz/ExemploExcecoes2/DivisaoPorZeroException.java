
public class DivisaoPorZeroException extends ArithmeticException {
	public DivisaoPorZeroException() {
		super("/ por zero (em portugues!)");
	}
}
