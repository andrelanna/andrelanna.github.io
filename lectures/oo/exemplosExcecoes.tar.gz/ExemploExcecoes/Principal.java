import javax.swing.JOptionPane;

public class Principal {

	public static void main(String[] args) {
		int numerador=0;
		int denominador;
		float quociente = 0;
		try {
			numerador = Integer.parseInt(JOptionPane
					.showInputDialog("Numerador:"));

			denominador = Integer.parseInt(JOptionPane
					.showInputDialog("Denominador:"));

			quociente = numerador / denominador;
		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(null, "Formato invalido");
		} catch (ArithmeticException e) {
			JOptionPane.showMessageDialog(null,
					"Peeeen! Alterando denominador para 1.");
			denominador = 1;
			quociente = numerador / denominador;
		} finally {
			JOptionPane.showMessageDialog(null, quociente);
		}

	}
}
