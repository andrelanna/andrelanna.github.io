
public class Calculadora {
	int operando1, operando2, resultado;

	public Calculadora() {
	}

	public Calculadora(int op1, int op2) {
		operando1 = op1;
		operando2 = op2;
	}

	int soma() {
		return operando1 + operando2;
	}

	int subtracao() {
		return operando1 - operando2;
	}

	int multiplicacao() {
		return operando1 * operando2;
	}

	int divisao() throws ArithmeticException {
		int resultado = -1;

		resultado = operando1 / operando2;

		return resultado;
	}
}
