package aula3.classes;

public class Principal {
	public static void main(String[] args) {
		Carro c = null;
		
		c = new Carro();
		c.marca = "Honda";
		System.out.println(c);
		c.imprimirEstado();
		
		Carro d = null;
		d = new Carro();
		System.out.println(d);
		d.imprimirEstado();
	}
}
