package aula3.classes;

public class Carro {
	String marca, 
	       modelo, 
	       cor;
	int anoFab,
	    anoMod,
	    capacidadePassageiros;
	float capacidadeCarga, 
	      velocidade;
	boolean ligado;
	
	
	void imprimirEstado() {
		String resposta = ""; 
		resposta += "Marca: " + marca + '\n';
		resposta += "Modelo: " + modelo + '\n';
		resposta += "Cor: " + cor + '\n';
		resposta += "Ano fab.: " + anoFab + '\n';
		resposta += "Ano mod.: " + anoMod + '\n';
		resposta += "Cap. carga: " + capacidadeCarga + '\n';
		resposta += "Cap. passageiro: " + capacidadePassageiros + '\n';
		resposta += "Velocidade: " + velocidade + '\n';
		resposta += "Ligado: " + ligado;
		System.out.println(resposta);
 	}
	
}
