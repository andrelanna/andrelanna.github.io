import javax.swing.JOptionPane;


public class Principal {

	public static void main(String[] args) {
		Aluno a = new Aluno();
		String nome = JOptionPane.showInputDialog("Informe o nome do aluno:");
		a.setNome(nome);
		
		Aluno.cadastrar(a);
	}

}
