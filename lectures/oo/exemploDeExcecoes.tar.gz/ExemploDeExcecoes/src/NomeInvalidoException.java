
public class NomeInvalidoException 
	extends CadastroException {
	
	public NomeInvalidoException(String msg) {
		super(msg);
	}
}
