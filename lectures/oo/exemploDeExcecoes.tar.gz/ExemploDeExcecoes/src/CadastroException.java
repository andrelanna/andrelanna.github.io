
public class CadastroException extends Exception {

	public CadastroException(String msg) {
		super(msg);
	}

}
