import java.util.LinkedList;
import java.util.List;

import javax.swing.JOptionPane;

public class Aluno {
	private String nome;
	private String matricula;
	private String email;

	private static List<Aluno> alunos = 
			new LinkedList<Aluno>();
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		if (nome.equals(""))
			try {
				throw new NomeEmBrancoException("O nome não pode ser em branco");
			} catch (NomeEmBrancoException e) {
				nome = JOptionPane.showInputDialog("Informe novamente: ");
				setNome(nome);
				e.printStackTrace();
			}
		
		if (!nome.contains(" ")){
			try {
				throw new NomeInvalidoException("O nome não contem o sobrenome!");
			} catch (NomeInvalidoException e) {
				nome = JOptionPane.showInputDialog("Informe novamente: ");
				setNome(nome);
				e.printStackTrace();
			}
		}
		this.nome = nome;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public static boolean cadastrar(Aluno a) {
		return alunos.add(a);
	}
}
