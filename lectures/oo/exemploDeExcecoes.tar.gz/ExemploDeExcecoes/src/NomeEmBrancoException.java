
public class NomeEmBrancoException 
	extends CadastroException {

	public NomeEmBrancoException(String msg) {
		super(msg);
	}

}
