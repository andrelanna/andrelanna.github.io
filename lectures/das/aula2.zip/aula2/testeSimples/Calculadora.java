package aula2.testeSimples;

public class Calculadora {

	public static int soma(int op1, int op2) {
		return op1 + op2;
	}

	public static int subtracao(int op1, int op2) {
		return op1 - op2;
	}

}
